# Como colocar no GitHub e “compilar”

Não é APK. É Node. “Compilar” = instalar deps + browser + rodar.

## 1. Repo
```bash
cd RewardsFarm
git init
git add .
git commit -m "RewardsFarm BEYOND"
# crie repo vazio no GitHub, depois:
git remote add origin https://github.com/SEU_USER/rewards-farm.git
git branch -M main
git push -u origin main
```

**Nunca commite** `data/accounts.json` com senhas. Só `accounts.example.json`.
Adicione ao `.gitignore`:
```
data/accounts.json
data/live-state.json
data/progress/
data/risk-state.json
sessions/
node_modules/
.env
```

## 2. No PC / VPS (uso real)
```bash
git clone https://github.com/SEU_USER/rewards-farm.git
cd rewards-farm
cp data/accounts.example.json data/accounts.json
# edite proxies, senhas, totpSecret
npm install
npm run install:browser
npm run api
# painel: http://IP:3921/
```

## 3. GitHub Actions
Push na `main` → workflow `ci.yml` instala patchright/playwright e gera artifact `rewards-farm-dist.zip`.
Baixe em Actions → Artifacts (sem node_modules; rode `npm install` local).

## 4. Docker no VPS
```bash
export API_TOKEN=token_longo
docker compose up -d
```

## 5. Celular
Abra `http://IP-do-VPS:3921/` → botão Rodar tudo.
