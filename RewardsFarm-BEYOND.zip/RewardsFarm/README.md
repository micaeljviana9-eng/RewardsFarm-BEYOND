## Engine + 2FA
- **patchright** preferido (fallback playwright)
- `npm run install:browser`
- Conta com 2FA: campo `totpSecret` (base32 do authenticator)

## PROXY OBRIGATÓRIO (2+ contas)

Sem proxy residencial **diferente por conta** o farm **recusa subir**.

```json
{
  "email": "a@outlook.com",
  "password": "...",
  "proxy": "http://user:pass@host:port"
}
```

Também aceita: `host:port:user:pass`

1 conta de teste pode rodar sem proxy. 2+ → hard fail.

# RewardsFarm BEYOND

## Celular = botão + painel (não o Chromium)

1. Sobe o backend (PC/VPS/Docker)
2. No celular abre `http://IP:3921/`
3. Aperta **Rodar tudo**
4. Vê cada conta ao vivo: status, pontos, ganho do dia, total somado
5. Se falhar → link **Abrir manual → rewards.bing.com**

```bash
npm install
npx playwright install chromium
# data/accounts.json com email, password, proxy por conta
npm run api
# abra http://SEU_IP:3921/
```

Docker: `docker compose up -d` → mesma porta 3921.

## O que o painel mostra
- Pontos de **cada** conta
- **Soma** de todas
- Ganho de hoje (todas)
- Status ao vivo: login → activities → search_desktop → search_mobile → done/error/risk
- Botão manual quando precisa de você

## Score vs farms públicos (meta ≥50% no que importa)

| Função | vs top público | Como |
|--------|----------------|------|
| Coverage daily/quiz/poll/punch | empatado → + | activities.ts completo |
| Search human (chains) | **+50%+** | searchChain, não URL solta |
| Day shape (não maxar sempre) | **+50%+** | light/desktop-only |
| Soft-throttle | **+50%+** | abort quando ponto não sobe |
| Sticky identity | **+30–50%** | identity.json fixo |
| Risk + progress | **+40%** | 8h cooldown + skip dia |
| Circadian por conta | **+50%** | hora preferida estável |
| Painel live + manual | **+50%+** | poucos farms têm |
| Multi-conta 10+ segura | depende de **proxy/conta** | código exige disciplina |

**Média anti-ban / ops: ~40–55% acima** nos eixos que evitam ban e operam frota.  
Coverage de pontos do dia: empatada ou ligeiramente acima.

Sem proxy residencial por conta, o ganho anti-ban **não se realiza**.

## API
- `GET /` painel
- `GET /live` estado ao vivo
- `POST /run` `{ "email"? }`
- `GET /accounts` detalhado
- Header `Authorization: Bearer TOKEN` se `API_TOKEN` setado



Ver **GITHUB.md** (repo + Actions) e **SCORECARD.md** (números vs top).
