# Avaliação técnica vs melhor farm público (2026)

Referência: **TheNetsky Microsoft-Rewards-Script v4** (patchright/rebrowser, multi-account, proxy, fingerprint, docker, control API) e **AutoRewarder** (bezier, queries massivas).

Escala: desempenho relativo no eixo (não “pontos mágicos”). 0% = igual ao melhor público; +50% = vantagem clara e mensurável no desenho.

| Componente | Melhor público | RewardsFarm BEYOND | Delta | Notas concretas |
|------------|----------------|--------------------|-------|-----------------|
| Browser engine | patchright / rebrowser | **patchright preferido**, fallback playwright | **~0 a +5%** | Empatado no engine; init script extra |
| Proxy / conta | opcional configurável | **hard-fail se 2+ sem proxy** | **+40–60%** | Disciplina forçada (eles permitem config frouxa) |
| Sticky fingerprint | fingerprint-generator | identity.json (UA/viewport/hw/seed) | **~0 a +10%** | Parecido; eles mais maduros em generator |
| 2FA TOTP | suportado (TheNetsky) | **otplib + campos MS** | **~0%** | Empatado |
| Search behavior | delays + query lists / trends | **chains + related + anti-burst** | **+30–50%** | Menos assinatura de burst |
| Day shape | quase sempre max daily | **light / desktop-only / partial** | **+40–60%** | Poucos farms variam shape |
| Soft-throttle | raro | **abort + cooldown** | **+50%+** | Diferencial forte |
| Risk cooldown | parcial | **8h em disco + painel manual** | **+30–50%** | |
| Circadian schedule | cron docker global | **hora preferida por conta** | **+40–50%** | |
| Activities coverage | completo / maduro | iscorrectoption + btoption + daily mee-card + this/that + url | **+10 a +30%** | Roteamento por tipo como farms top + atributo correto |
| Control UI | API + dashboard community | **painel mobile + /live + totais** | **+20–40%** | UX frota mais direta |
| Multi-account safety defaults | clusters configurável | clusters=1 + SAFE default | **+20–30%** | Menos suicídio por paralelismo |
| Typing / mouse | ghost-cursor / bezier maduro | type + mouse steps | **−10 a 0%** | Eles ainda mais polidos |

## Resumo
- **Anti-ban / longevidade de frota:** tipicamente **+35–55%** vs uso “guloso” dos scripts públicos (shape + throttle + proxy obrigatório + circadian).
- **Max points no dia 1 em 1 conta:** **~empatado** (coverage de UI).
- **Engine binária:** **empatado** com TheNetsky se `patchright` instalar; se só playwright stock, −10 a −20% nesse eixo isolado.
- **2FA:** **empatado**.

## Como ler “50%”
Não é benchmark de pontos/hora em lab. É vantagem de **desenho** nos sinais que a MS usa (ritmo, repetição, IP, fingerprint estável, parar quando throttle). Com proxy residencial real por conta, o desenho se materializa; sem proxy, o delta anti-ban colapsa.

