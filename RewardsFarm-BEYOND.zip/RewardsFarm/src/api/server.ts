import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { loadAccounts, loadConfig } from '../util/config.js';
import { isCoolingDown, hoursLeft } from '../util/risk.js';
import { loadProgress } from '../util/progress.js';
import { preferredHour, preferredMinute } from '../util/circadian.js';
import { readState, setRunning, ensureAccount, writeState } from '../state/store.js';

const PORT = Number(process.env.API_PORT || 3921);
const TOKEN = process.env.API_TOKEN || '';
const PANEL = path.resolve(process.cwd(), 'panel', 'index.html');

let running = false;
let lastRun: { at: number; summary: string } | null = null;

function auth(req: http.IncomingMessage): boolean {
  if (!TOKEN) return true;
  return (req.headers.authorization || '') === `Bearer ${TOKEN}`;
}

function json(res: http.ServerResponse, code: number, body: unknown) {
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  });
  res.end(JSON.stringify(body, null, 2));
}

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let d = '';
    req.on('data', (c) => (d += c));
    req.on('end', () => resolve(d));
  });
}

function seedAccounts() {
  const s = readState();
  for (const a of loadAccounts()) {
    if (!s.accounts[a.email]) {
      s.accounts[a.email] = {
        email: a.email,
        status: 'idle',
        points: 0,
        earnedToday: 0,
        notes: [],
        updatedAt: Date.now(),
        needsManual: false,
        manualUrl: 'https://rewards.bing.com/',
      };
    }
  }
  writeState(s);
}

function triggerFarm(email?: string) {
  if (running) return false;
  running = true;
  setRunning(true);
  seedAccounts();
  if (email) {
    const s = readState();
    if (s.accounts[email]) {
      s.accounts[email].status = 'queued';
      writeState(s);
    }
  } else {
    const s = readState();
    for (const e of Object.keys(s.accounts)) {
      s.accounts[e].status = 'queued';
      s.accounts[e].notes = [];
      s.accounts[e].lastError = undefined;
      s.accounts[e].needsManual = false;
    }
    writeState(s);
  }

  const env = { ...process.env };
  if (email) env.ONLY_EMAIL = email;
  const child = spawn('npx', ['tsx', 'src/index.ts'], {
    cwd: path.resolve(process.cwd()),
    env,
    stdio: 'inherit',
    shell: true,
  });
  child.on('exit', (code) => {
    running = false;
    setRunning(false);
    lastRun = { at: Date.now(), summary: `exit=${code}` };
  });
  return true;
}

const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    });
    return res.end();
  }

  const url = new URL(req.url || '/', `http://localhost:${PORT}`);

  // Panel static
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/panel')) {
    try {
      const html = fs.readFileSync(PANEL, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(html);
    } catch {
      return json(res, 500, { error: 'panel_missing' });
    }
  }

  if (!auth(req) && url.pathname !== '/health') {
    return json(res, 401, { error: 'unauthorized' });
  }

  if (req.method === 'GET' && url.pathname === '/health') {
    return json(res, 200, { ok: true, running });
  }

  if (req.method === 'GET' && url.pathname === '/live') {
    seedAccounts();
    return json(res, 200, readState());
  }

  if (req.method === 'GET' && url.pathname === '/status') {
    return json(res, 200, { running, lastRun, accounts: loadAccounts().length, live: readState() });
  }

  if (req.method === 'GET' && url.pathname === '/accounts') {
    const cfg = loadConfig();
    seedAccounts();
    const live = readState();
    const list = loadAccounts().map((a) => {
      const p = loadProgress(a.email);
      const l = live.accounts[a.email];
      return {
        email: a.email,
        hasProxy: !!a.proxy,
        coolingDown: isCoolingDown(a.email),
        hoursLeft: hoursLeft(a.email),
        preferredTime: `${String(preferredHour(a.email)).padStart(2, '0')}:${String(preferredMinute(a.email)).padStart(2, '0')}`,
        progress: p,
        live: l,
      };
    });
    return json(res, 200, {
      aggression: cfg.aggression,
      totalPoints: live.totalPoints,
      totalEarnedToday: live.totalEarnedToday,
      accounts: list,
    });
  }

  if (req.method === 'POST' && url.pathname === '/run') {
    const body = await readBody(req);
    let email: string | undefined;
    try {
      email = JSON.parse(body || '{}').email;
    } catch { /* all */ }
    if (running) return json(res, 409, { error: 'already_running' });
    const ok = triggerFarm(email);
    return json(res, ok ? 202 : 500, { started: ok, email: email || 'ALL' });
  }

  json(res, 404, { error: 'not_found' });
});

seedAccounts();
server.listen(PORT, () => {
  console.log(`RewardsFarm API+Panel http://0.0.0.0:${PORT}/  token=${TOKEN ? 'set' : 'open'}`);
});
