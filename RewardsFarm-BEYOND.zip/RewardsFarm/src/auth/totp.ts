import { authenticator } from 'otplib';

/**
 * TOTP 2FA — secret is the base32 key from Microsoft authenticator setup
 * (not the 6-digit code). Store per account as totpSecret.
 */
export function generateTotp(secret: string): string {
  const clean = secret.replace(/\s+/g, '').toUpperCase();
  return authenticator.generate(clean);
}

export function verifyTotp(secret: string, token: string): boolean {
  try {
    return authenticator.verify({ token, secret: secret.replace(/\s+/g, '').toUpperCase() });
  } catch {
    return false;
  }
}
