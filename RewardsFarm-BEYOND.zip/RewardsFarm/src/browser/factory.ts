import path from 'path';
import fs from 'fs';
import type { Browser, BrowserContext, Page } from 'playwright';
import type { Account, FarmConfig } from '../util/types.js';
import { sessionDir } from '../util/config.js';
import { loadOrCreateIdentity, type Identity } from '../util/identity.js';
import { toPlaywrightProxy } from '../util/proxy.js';

export interface Session {
  browser: Browser;
  context: BrowserContext;
  page: Page;
  identity: Identity;
  engine: 'patchright' | 'playwright';
  close: () => Promise<void>;
}

async function loadChromium() {
  // Prefer patchright (binary-level anti-detection). Fallback to playwright.
  try {
    const mod = await import('patchright');
    return { chromium: mod.chromium, engine: 'patchright' as const };
  } catch {
    const mod = await import('playwright');
    return { chromium: mod.chromium, engine: 'playwright' as const };
  }
}

export async function openSession(
  account: Account,
  config: FarmConfig,
  mode: 'desktop' | 'mobile' = 'desktop'
): Promise<Session> {
  const identity = loadOrCreateIdentity(
    config.sessionPath,
    account.email,
    account.locale || config.locale,
    config.timezoneId
  );
  const userData = sessionDir(config.sessionPath, `${account.email}_${mode}`);
  const proxy = toPlaywrightProxy(account.proxy);
  if (account.proxy && !proxy) {
    throw new Error(`Proxy inválido para ${account.email}: ${account.proxy}`);
  }
  if (!account.proxy) {
    console.warn(`[proxy] ${account.email} SEM proxy — só 1 conta de teste`);
  }

  const { chromium, engine } = await loadChromium();
  console.log(`[engine] ${engine} · ${account.email} · ${mode}`);

  const browser = await chromium.launch({
    headless: config.headless,
    proxy,
    args: [
      '--disable-blink-features=AutomationControlled',
      '--no-default-browser-check',
      '--disable-dev-shm-usage',
    ],
  });

  const context = await browser.newContext({
    locale: identity.locale,
    timezoneId: identity.timezoneId,
    viewport: mode === 'mobile' ? { width: 390, height: 844 } : identity.viewport,
    userAgent: mode === 'mobile' ? identity.userAgentMobile : identity.userAgentDesktop,
    isMobile: mode === 'mobile',
    hasTouch: mode === 'mobile',
    deviceScaleFactor: mode === 'mobile' ? 3 : identity.deviceScaleFactor,
    permissions: [],
    colorScheme: 'light',
  });

  await context.addInitScript((id: Identity) => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    // @ts-expect-error
    window.chrome = window.chrome || { runtime: {}, app: {}, csi: () => ({}), loadTimes: () => ({}) };
    Object.defineProperty(navigator, 'languages', { get: () => [id.locale, 'pt', 'en-US', 'en'] });
    Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => id.hwConcurrency });
    Object.defineProperty(navigator, 'deviceMemory', { get: () => id.deviceMemory });
    Object.defineProperty(navigator, 'platform', {
      get: () => (navigator.userAgent.includes('Android') ? 'Linux armv8l' : 'Win32'),
    });
    Object.defineProperty(navigator, 'maxTouchPoints', {
      get: () => (navigator.userAgent.includes('Android') ? 5 : 0),
    });
  }, identity);

  const stateFile = path.join(userData, 'state.json');
  if (fs.existsSync(stateFile)) {
    try {
      const state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
      if (state.cookies?.length) await context.addCookies(state.cookies);
    } catch { /* first run */ }
  }

  const page = await context.newPage();
  page.setDefaultTimeout(config.globalTimeoutMs);

  const close = async () => {
    try {
      const state = await context.storageState();
      fs.mkdirSync(userData, { recursive: true });
      fs.writeFileSync(stateFile, JSON.stringify(state, null, 2));
    } catch { /* ignore */ }
    await context.close().catch(() => null);
    await browser.close().catch(() => null);
  };

  return { browser, context, page, identity, engine, close };
}
