import type { Page } from 'playwright';
import { humanSleep, humanMs } from './delays.js';

export async function humanType(page: Page, selector: string, text: string, mult = 1) {
  const el = page.locator(selector).first();
  await el.click({ delay: humanMs(80, 0.3, mult) });
  await humanSleep(200, 0.4, mult);
  for (const ch of text) {
    await page.keyboard.type(ch, { delay: humanMs(70, 0.5, mult) });
    if (Math.random() < 0.08) await humanSleep(280, 0.5, mult);
  }
}

export async function humanClick(page: Page, selector: string, mult = 1) {
  const loc = page.locator(selector).first();
  await loc.waitFor({ state: 'visible', timeout: 8000 }).catch(() => null);
  const box = await loc.boundingBox().catch(() => null);
  if (box) {
    const x = box.x + box.width * (0.3 + Math.random() * 0.4);
    const y = box.y + box.height * (0.3 + Math.random() * 0.4);
    await page.mouse.move(x, y, { steps: 8 + Math.floor(Math.random() * 12) });
    await humanSleep(80, 0.4, mult);
    await page.mouse.click(x, y, { delay: humanMs(60, 0.3, mult) });
  } else {
    await loc.click({ delay: humanMs(60, 0.3, mult) }).catch(() => null);
  }
}

export async function humanScroll(page: Page, mult = 1) {
  const dy = 200 + Math.floor(Math.random() * 500);
  await page.mouse.wheel(0, dy);
  await humanSleep(600, 0.4, mult);
}

export async function dwell(page: Page, median = 3500, mult = 1) {
  if (Math.random() < 0.55) await humanScroll(page, mult);
  await humanSleep(median, 0.5, mult);
  if (Math.random() < 0.3) await humanScroll(page, mult);
}

export async function detectRisk(page: Page): Promise<boolean> {
  const body = (await page.locator('body').innerText().catch(() => '')).toLowerCase();
  const signals = [
    'unusual activity', 'atividade incomum', 'atividade suspeita',
    "we've noticed", 'detectamos', 'temporariamente limitado',
    'temporarily limited', 'account suspended', 'conta suspensa',
    'verify your account', 'captcha', 'too many requests'
  ];
  return signals.some(s => body.includes(s));
}
