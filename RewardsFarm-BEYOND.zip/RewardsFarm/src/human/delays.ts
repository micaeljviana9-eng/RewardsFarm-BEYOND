/** Log-normal-ish delay */
export function humanMs(median: number, sigma = 0.45, mult = 1): number {
  const u = Math.min(0.999, Math.max(0.001, Math.random()));
  // Box-Muller
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random());
  const v = median * Math.exp(sigma * z) * mult;
  return Math.floor(Math.min(median * 5, Math.max(median / 4, v)));
}

export async function sleep(ms: number) {
  return new Promise(r => setTimeout(r, ms));
}

export async function humanSleep(median: number, sigma = 0.45, mult = 1) {
  await sleep(humanMs(median, sigma, mult));
}
