import { loadAccounts, loadConfig, aggressionProfile } from './util/config.js';
import { isCoolingDown, hoursLeft, markRisk } from './util/risk.js';
import { openSession } from './browser/factory.js';
import { tryLogin, goDashboard, scrapePoints } from './tasks/dashboard.js';
import { runAllActivities } from './tasks/activities.js';
import { runReadToEarn } from './tasks/readToEarn.js';
import { runDailyCheckIn } from './tasks/checkIn.js';
import { runSearchChains } from './tasks/searchChain.js';
import { detectRisk } from './human/actions.js';
import { humanSleep } from './human/delays.js';
import { loadProgress, saveProgress } from './util/progress.js';
import type { RunResult } from './util/types.js';
import { shouldRunNow, preferredHour, preferredMinute } from './util/circadian.js';
import { patchAccount, setRunning } from './state/store.js';
import { assertAccountProxies } from './util/proxy.js';

async function runAccount(
  email: string,
  password: string,
  proxy: string | undefined,
  config: ReturnType<typeof loadConfig>,
  totpSecret?: string
): Promise<RunResult> {
  const notes: string[] = [];

  if (isCoolingDown(email)) {
    return {
      email, success: false, pointsBefore: 0, pointsAfter: 0, earned: 0, risk: true,
      notes: [`cooldown_${hoursLeft(email)}h`], error: 'RISK_COOLDOWN',
    };
  }

  const progress = loadProgress(email);
  patchAccount(email, { status: 'login', notes: [], lastError: undefined, needsManual: false });
  if (progress.completed) {
    return {
      email, success: true, pointsBefore: 0, pointsAfter: 0, earned: 0, risk: false,
      notes: ['already_completed_today'],
    };
  }

  // Circadian-ish jitter (per process; for production use external cron + this)
  const jitter = Math.floor(Math.random() * Math.min(config.jitterStartMinutes, 20) * 60 * 1000);
  if (jitter > 3000) {
    console.log(`[${email}] jitter ${Math.round(jitter / 1000)}s`);
    await humanSleep(jitter, 0.15);
  }

  // Day shape variation — do NOT always run full max (surpasses farms that always 100% cap)
  let desktopTarget = config.desktopSearches;
  let mobileTarget = config.mobileSearches;
  let doCards = config.doDailySet || config.doPromotions;
  if ((config as any).varyDayShape !== false) {
    const roll = Math.random();
    if (roll < 0.15) {
      // light day
      desktopTarget = Math.floor(desktopTarget * 0.55);
      mobileTarget = Math.floor(mobileTarget * 0.5);
      notes.push('shape=light');
    } else if (roll < 0.3) {
      // desktop only
      mobileTarget = 0;
      notes.push('shape=desktop_only');
    } else if (roll < 0.4) {
      // skip cards sometimes
      doCards = Math.random() > 0.5;
      notes.push('shape=partial_cards');
    } else {
      notes.push('shape=full');
    }
  }

  desktopTarget = Math.max(0, desktopTarget - progress.desktopSearches);
  mobileTarget = Math.max(0, mobileTarget - progress.mobileSearches);

  const account = { email, password, proxy, enabled: true };
  let session: Awaited<ReturnType<typeof openSession>> | null = null;

  try {
    session = await openSession(account, config, 'desktop');
    const { page, identity } = session;
    notes.push(`id=${identity.seed}`);

    const ok = await tryLogin(page, email, password, totpSecret);
    if (!ok) {
      patchAccount(email, { status: 'manual', needsManual: true, lastError: 'LOGIN', manualUrl: 'https://rewards.bing.com/' });
      return { email, success: false, pointsBefore: 0, pointsAfter: 0, earned: 0, risk: false, notes: [...notes, 'login_failed'], error: 'LOGIN' };
    }

    await goDashboard(page);
    if (await detectRisk(page)) {
      markRisk(email, 'banner_start', config.riskCooldownHours);
      patchAccount(email, { status: 'risk', needsManual: true, lastError: 'RISK' });
      return { email, success: false, pointsBefore: 0, pointsAfter: 0, earned: 0, risk: true, notes, error: 'RISK' };
    }

    const pointsBefore = await scrapePoints(page);
    notes.push(`before=${pointsBefore}`);
    let lastPoints = pointsBefore;

    // Check-in streak (print: Day 2)
    patchAccount(email, { status: 'activities' });
    const checked = await runDailyCheckIn(page);
    notes.push(`checkin=${checked}`);

    // Read to Earn (print: 0/30)
    const readN = await runReadToEarn(page, 8);
    if (readN < 0) {
      markRisk(email, 'banner_read', config.riskCooldownHours);
      patchAccount(email, { status: 'risk', needsManual: true, lastError: 'RISK' });
      return { email, success: false, pointsBefore, pointsAfter: pointsBefore, earned: 0, risk: true, notes, error: 'RISK' };
    }
    notes.push(`read=${readN}`);
    await goDashboard(page);

    if (doCards) {
      patchAccount(email, { status: 'activities' });
      const act = await runAllActivities(page);
      if (act.risk) {
        markRisk(email, 'banner_activities', config.riskCooldownHours);
        return { email, success: false, pointsBefore, pointsAfter: pointsBefore, earned: 0, risk: true, notes, error: 'RISK' };
      }
      const cardScore = act.promotions + act.punch + act.dailySet.explore
        + (act.dailySet.quiz > 0 ? 1 : 0) + (act.dailySet.poll > 0 ? 1 : 0);
      progress.cardsDone += cardScore;
      notes.push(
        `quiz=${act.dailySet.quiz}`,
        `poll=${act.dailySet.poll}`,
        `explore=${act.dailySet.explore}`,
        `promo=${act.promotions}`,
        `punch=${act.punch}`,
        `kinds=${(act.kinds || []).join('+')}`
      );
    }

    if (config.doDesktopSearch && desktopTarget > 0) {
      patchAccount(email, { status: 'search_desktop' });
      const search = await runSearchChains(
        page,
        desktopTarget,
        config.aggression,
        config.searchBaseGapMs,
        config.searchAntiBurstEvery,
        config.searchBurstCooldownMs
      );
      progress.desktopSearches += search.done;
      notes.push(`desk_search=${search.done}`);
      if (search.risk) {
        markRisk(email, 'banner_search', config.riskCooldownHours);
        const pointsAfter = await scrapePoints(page);
        saveProgress(email, progress);
        return {
          email, success: false, pointsBefore, pointsAfter,
          earned: Math.max(0, pointsAfter - pointsBefore), risk: true, notes, error: 'RISK',
        };
      }
      // Soft throttle: points not moving after a block
      await goDashboard(page);
      const mid = await scrapePoints(page);
      if (mid <= lastPoints && search.done >= 6) {
        progress.softThrottleHits += 1;
        notes.push('soft_throttle');
        const abortAfter = (config as any).softThrottleAbortAfter ?? 4;
        if (progress.softThrottleHits >= abortAfter) {
          notes.push('abort_soft_throttle');
          saveProgress(email, progress);
          markRisk(email, 'soft_throttle', Math.max(2, Math.floor(config.riskCooldownHours / 2)));
          return {
            email, success: true, pointsBefore, pointsAfter: mid,
            earned: Math.max(0, mid - pointsBefore), risk: true, notes, error: 'SOFT_THROTTLE',
          };
        }
      } else {
        lastPoints = mid;
      }
    }

    if (config.doMobileSearch && mobileTarget > 0) {
      patchAccount(email, { status: 'search_mobile' });
      await session.close();
      session = await openSession(account, config, 'mobile');
      await tryLogin(session.page, email, password, totpSecret);
      const mob = await runSearchChains(
        session.page,
        mobileTarget,
        config.aggression,
        config.searchBaseGapMs,
        config.searchAntiBurstEvery,
        config.searchBurstCooldownMs
      );
      progress.mobileSearches += mob.done;
      notes.push(`mob_search=${mob.done}`);
      if (mob.risk) markRisk(email, 'banner_mobile', config.riskCooldownHours);
    }

    await goDashboard(session.page);
    const pointsAfter = await scrapePoints(session.page);
    const earned = Math.max(0, pointsAfter - pointsBefore);
    progress.lastEarned = earned;
    // Mark complete if we did a meaningful pass
    if (progress.desktopSearches + progress.mobileSearches >= 10 || earned > 0) {
      progress.completed = true;
    }
    saveProgress(email, progress);
    notes.push(`after=${pointsAfter}`, `earned=${earned}`);
    patchAccount(email, { status: 'done', points: pointsAfter, earnedToday: earned, notes: notes.slice(-8) });

    return { email, success: true, pointsBefore, pointsAfter, earned, risk: false, notes };
  } catch (e: any) {
    saveProgress(email, progress);
    patchAccount(email, { status: 'error', needsManual: true, lastError: e?.message || String(e) });
    return {
      email, success: false, pointsBefore: 0, pointsAfter: 0, earned: 0, risk: false,
      notes, error: e?.message || String(e),
    };
  } finally {
    if (session) await session.close();
  }
}

async function main() {
  const config = loadConfig();
  let accounts = loadAccounts();
  if (process.env.ONLY_EMAIL) {
    accounts = accounts.filter(a => a.email === process.env.ONLY_EMAIL);
  }
  if (process.env.CIRCADIAN === '1') {
    accounts = accounts.filter(a => shouldRunNow(a.email));
    console.log(`Circadian filter → ${accounts.length} due now`);
  }

  setRunning(true);
  console.log(`RewardsFarm BEYOND — accounts=${accounts.length} aggression=${config.aggression} clusters=${config.clusters}`);
  console.log('Defaults: SAFE-first, day-shape variation, search chains, soft-throttle abort, sticky identity');

  if (!accounts.length) {
    console.error('No accounts in data/accounts.json');
    process.exit(1);
  }

  const proxyCheck = assertAccountProxies(accounts, { requireAll: accounts.length >= 2 });
  if (!proxyCheck.ok) {
    console.error('PROXY OBRIGATÓRIO por conta (2+ contas):');
    for (const e of proxyCheck.errors) console.error(' -', e);
    console.error('Formato: http://user:pass@host:port  OU  host:port:user:pass');
    process.exit(1);
  }


  const results: RunResult[] = [];
  const chunk = Math.max(1, config.clusters);

  for (let i = 0; i < accounts.length; i += chunk) {
    const batch = accounts.slice(i, i + chunk);
    const batchResults = await Promise.all(
      batch.map(a => runAccount(a.email, a.password, a.proxy, config, a.totpSecret))
    );
    results.push(...batchResults);
    for (const r of batchResults) console.log(JSON.stringify(r));
    if (i + chunk < accounts.length) await humanSleep(45000, 0.3);
  }

  const earned = results.reduce((s, r) => s + r.earned, 0);
  setRunning(false);
  console.log(`Done. n=${results.length} earned~=${earned}`);
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});
