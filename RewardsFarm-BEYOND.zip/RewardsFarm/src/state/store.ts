import fs from 'fs';
import path from 'path';

export type AccountStatus =
  | 'idle'
  | 'queued'
  | 'login'
  | 'activities'
  | 'search_desktop'
  | 'search_mobile'
  | 'done'
  | 'error'
  | 'risk'
  | 'manual';

export interface AccountLive {
  email: string;
  status: AccountStatus;
  points: number;
  earnedToday: number;
  lastError?: string;
  notes: string[];
  updatedAt: number;
  needsManual: boolean;
  manualUrl?: string;
}

export interface LiveState {
  running: boolean;
  startedAt?: number;
  finishedAt?: number;
  accounts: Record<string, AccountLive>;
  totalPoints: number;
  totalEarnedToday: number;
}

const FILE = path.join(process.cwd(), 'data', 'live-state.json');

function empty(): LiveState {
  return { running: false, accounts: {}, totalPoints: 0, totalEarnedToday: 0 };
}

export function readState(): LiveState {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return empty();
  }
}

export function writeState(s: LiveState) {
  s.totalPoints = Object.values(s.accounts).reduce((a, c) => a + (c.points || 0), 0);
  s.totalEarnedToday = Object.values(s.accounts).reduce((a, c) => a + (c.earnedToday || 0), 0);
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(s, null, 2));
}

export function ensureAccount(email: string): AccountLive {
  const s = readState();
  if (!s.accounts[email]) {
    s.accounts[email] = {
      email,
      status: 'idle',
      points: 0,
      earnedToday: 0,
      notes: [],
      updatedAt: Date.now(),
      needsManual: false,
      manualUrl: 'https://rewards.bing.com/',
    };
    writeState(s);
  }
  return s.accounts[email];
}

export function patchAccount(email: string, patch: Partial<AccountLive>) {
  const s = readState();
  const cur = s.accounts[email] || ensureAccount(email);
  s.accounts[email] = { ...cur, ...patch, email, updatedAt: Date.now() };
  writeState(s);
}

export function setRunning(running: boolean) {
  const s = readState();
  s.running = running;
  if (running) s.startedAt = Date.now();
  else s.finishedAt = Date.now();
  writeState(s);
}
