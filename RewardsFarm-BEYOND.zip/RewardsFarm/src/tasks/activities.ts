import type { Page } from 'playwright';
import { humanClick, detectRisk, dwell, humanScroll } from '../human/actions.js';
import { humanSleep } from '../human/delays.js';

/**
 * Full daily points coverage — aligned with top farms' activity routing:
 * - urlreward (open + wait)
 * - quiz 10pts → poll (btoption) or ABC
 * - quiz 30–40 → multi-question with iscorrectoption when present
 * - quiz 50 → This or That
 * - daily set cards via mee-card / data-bi-id
 */

async function closeExtra(page: Page) {
  for (const p of page.context().pages()) {
    if (p !== page) await p.close().catch(() => null);
  }
}

async function backHome(page: Page) {
  await closeExtra(page);
  if (!page.url().includes('rewards.bing.com')) {
    await page.goto('https://rewards.bing.com/', { waitUntil: 'domcontentloaded' }).catch(() => null);
    await humanSleep(1500, 0.4);
  }
}

/** Prefer correct answer attribute when MS exposes it */
async function clickQuizOptions(page: Page): Promise<boolean> {
  // iscorrectoption=true (8-option / standard quiz)
  for (let i = 0; i < 8; i++) {
    const el = page.locator(`#rqAnswerOption${i}`);
    if (!(await el.count())) continue;
    const flag = await el.getAttribute('iscorrectoption').catch(() => null);
    if (flag && flag.toLowerCase() === 'true') {
      await el.click({ delay: 50 + Math.random() * 80 }).catch(() => null);
      return true;
    }
  }
  // fallback random among visible rqAnswerOption*
  const opts = page.locator('[id^="rqAnswerOption"]');
  const n = await opts.count();
  if (n > 0) {
    await opts.nth(Math.floor(Math.random() * n)).click({ delay: 60 }).catch(() => null);
    return true;
  }
  // generic option buttons
  const gen = page.locator(
    '.rqOption, .wk_choicesInstLink, [class*="rq_button"], #currentQuestionContainer button'
  );
  const g = await gen.count();
  if (g > 0) {
    await gen.nth(Math.floor(Math.random() * g)).click({ delay: 60 }).catch(() => null);
    return true;
  }
  return false;
}

async function startQuizIfNeeded(page: Page) {
  const start = page.locator('#rqStartQuiz, input#rqStartQuiz, button:has-text("Start"), button:has-text("Começar")');
  if (await start.first().isVisible().catch(() => false)) {
    await start.first().click({ delay: 50 }).catch(() => null);
    await humanSleep(1500, 0.4);
  }
}

/** Poll — btoption0 / btoption1 */
export async function completePoll(page: Page): Promise<boolean> {
  await humanSleep(1200, 0.4);
  const id = Math.random() < 0.5 ? '#btoption0' : '#btoption1';
  const el = page.locator(id);
  if (await el.isVisible().catch(() => false)) {
    await el.click({ delay: 60 }).catch(() => null);
    await humanSleep(2000, 0.4);
    return true;
  }
  // fallback
  const alts = page.locator('[id^="btoption"], .btOptionCard, [class*="poll"] button');
  const n = await alts.count();
  if (n >= 1) {
    await alts.nth(Math.floor(Math.random() * Math.min(n, 2))).click({ delay: 60 }).catch(() => null);
    await humanSleep(2000, 0.4);
    return true;
  }
  return false;
}

/** This or That — up to maxQuestions, options 0/1 */
export async function completeThisOrThat(page: Page, maxQuestions = 10): Promise<number> {
  await startQuizIfNeeded(page);
  let done = 0;
  for (let q = 0; q < maxQuestions; q++) {
    if (await detectRisk(page)) return -1;
    const complete = page.locator('#quizCompleteContainer, .rqDone, [class*="quizComplete"]');
    if (await complete.first().isVisible().catch(() => false)) break;

    const pick = Math.random() < 0.5 ? '#rqAnswerOption0' : '#rqAnswerOption1';
    if (await page.locator(pick).isVisible().catch(() => false)) {
      await page.locator(pick).click({ delay: 50 + Math.random() * 90 }).catch(() => null);
      done++;
    } else if (!(await clickQuizOptions(page))) {
      break;
    } else {
      done++;
    }
    await humanSleep(1800 + Math.random() * 1200, 0.45);
  }
  return done;
}

/** Standard / ABC quiz — use iscorrectoption when available */
export async function completeQuiz(page: Page, maxQuestions = 15): Promise<number> {
  await startQuizIfNeeded(page);
  let answered = 0;
  for (let q = 0; q < maxQuestions; q++) {
    if (await detectRisk(page)) return -1;
    if (await page.locator('#quizCompleteContainer, .rqDone').first().isVisible().catch(() => false)) break;

    // Try read maxQuestions from page script (best-effort)
    const clicked = await clickQuizOptions(page);
    if (!clicked) {
      // ABC style letter buttons
      const abc = page.locator('#rqAnswerOption0, #rqAnswerOption1, #rqAnswerOption2');
      const n = await abc.count();
      if (n === 0) break;
      await abc.nth(Math.floor(Math.random() * n)).click({ delay: 60 }).catch(() => null);
    }
    answered++;
    await humanSleep(1600 + Math.random() * 1400, 0.45);
  }
  return answered;
}

/** URL reward — open, dwell, close extras */
export async function completeUrlReward(page: Page): Promise<boolean> {
  await humanSleep(2500, 0.4);
  await dwell(page, 3500);
  await closeExtra(page);
  return true;
}

/** Route by page content after opening a card */
async function solveOpenedActivity(page: Page): Promise<string> {
  await humanSleep(2000, 0.4);
  const url = page.url().toLowerCase();
  const html = (await page.content().catch(() => '')).toLowerCase();

  if (url.includes('pollscenarioid') || (await page.locator('#btoption0, #btoption1').count()) > 0) {
    await completePoll(page);
    return 'poll';
  }
  if ((await page.locator('#rqStartQuiz, #rqAnswerOption0').count()) > 0) {
    // Heuristic: 2 options visible → this or that; else quiz
    const opts = await page.locator('[id^="rqAnswerOption"]').count();
    if (opts <= 2) {
      await completeThisOrThat(page);
      return 'thisorthat';
    }
    await completeQuiz(page);
    return 'quiz';
  }
  if (html.includes('rqansweroption') || html.includes('rqstartquiz')) {
    await completeQuiz(page);
    return 'quiz';
  }
  // generic url / explore
  await completeUrlReward(page);
  return 'url';
}

/** Click all incomplete daily-set / promo cards */
export async function runDailySetAndPromos(page: Page): Promise<{
  cards: number;
  kinds: string[];
  risk: boolean;
}> {
  const kinds: string[] = [];
  let cards = 0;

  await page.goto('https://rewards.bing.com/', { waitUntil: 'domcontentloaded' });
  await humanSleep(2200, 0.4);
  if (await detectRisk(page)) return { cards: 0, kinds, risk: true };

  await humanScroll(page);
  await humanSleep(800, 0.3);

  // Collect clickable activity cards (daily set + more)
  const cardSelectors = [
    '#daily-sets mee-card a',
    '#daily-sets [data-bi-id] a',
    'mee-rewards-daily-set-item-content a',
    '[data-bi-area*="DailySet"] a',
    '[data-bi-id*="DailySet"] a',
    '[data-bi-id*="dailyset"] a',
    'mee-card a.c-call-to-action',
    'mee-card a[href*="rewards"]',
    '[class*="daily-set"] a',
    '[class*="moreActivities"] a',
    '[class*="more-activities"] a',
  ];

  // Build list of hrefs/titles to click without stale handles
  const targets: { selector: string; index: number }[] = [];
  for (const sel of cardSelectors) {
    const loc = page.locator(sel);
    const n = await loc.count();
    for (let i = 0; i < n && targets.length < 16; i++) {
      const el = loc.nth(i);
      if (!(await el.isVisible().catch(() => false))) continue;
      // skip completed (checkmark / locked text)
      const parentText = (await el.locator('xpath=ancestor::mee-card|ancestor::div[1]').innerText().catch(() => '')) || '';
      if (/completed|concluído|done|✓|✔/i.test(parentText) && !/earn|pontuar|start|começar/i.test(parentText)) {
        continue;
      }
      targets.push({ selector: sel, index: i });
    }
  }

  // Deduplicate by clicking sequentially with re-query
  const maxCards = Math.min(targets.length || 12, 14);
  for (let attempt = 0; attempt < maxCards; attempt++) {
    if (await detectRisk(page)) return { cards, kinds, risk: true };

    // Re-find first incomplete-looking card each time (DOM changes)
    let clicked = false;
    for (const sel of cardSelectors) {
      const loc = page.locator(sel);
      const n = await loc.count();
      for (let i = 0; i < n; i++) {
        const el = loc.nth(i);
        if (!(await el.isVisible().catch(() => false))) continue;
        const box = await el.boundingBox().catch(() => null);
        if (!box || box.width < 8) continue;
        const t = ((await el.innerText().catch(() => '')) || '').toLowerCase();
        if (t.includes('completed') || t.includes('concluído')) continue;

        const pagesBefore = page.context().pages().length;
        await el.click({ delay: 55 + Math.random() * 70 }).catch(() => null);
        clicked = true;
        cards++;
        await humanSleep(2200, 0.45);

        // New tab?
        if (page.context().pages().length > pagesBefore) {
          const pages = page.context().pages();
          const extra = pages.find((p) => p !== page);
          if (extra) {
            const kind = await solveOpenedActivity(extra);
            kinds.push(kind);
            await extra.close().catch(() => null);
          }
        } else {
          const kind = await solveOpenedActivity(page);
          kinds.push(kind);
        }

        await backHome(page);
        break;
      }
      if (clicked) break;
    }
    if (!clicked) break;
    await humanSleep(1000, 0.4);
  }

  // Explicit poll/quiz leftovers on dashboard
  if (await page.locator('#btoption0').isVisible().catch(() => false)) {
    await completePoll(page);
    kinds.push('poll');
  }
  if (await page.locator('#rqStartQuiz, #rqAnswerOption0').first().isVisible().catch(() => false)) {
    await completeQuiz(page);
    kinds.push('quiz');
  }

  return { cards, kinds, risk: false };
}

export interface ActivityReport {
  dailySet: { quiz: number; poll: number; explore: number };
  promotions: number;
  punch: number;
  risk: boolean;
  kinds: string[];
}

export async function runAllActivities(page: Page): Promise<ActivityReport> {
  const report: ActivityReport = {
    dailySet: { quiz: 0, poll: 0, explore: 0 },
    promotions: 0,
    punch: 0,
    risk: false,
    kinds: [],
  };

  if (await detectRisk(page)) {
    report.risk = true;
    return report;
  }

  const r = await runDailySetAndPromos(page);
  report.risk = r.risk;
  report.kinds = r.kinds;
  report.promotions = r.cards;
  for (const k of r.kinds) {
    if (k === 'quiz' || k === 'thisorthat') report.dailySet.quiz++;
    else if (k === 'poll') report.dailySet.poll++;
    else report.dailySet.explore++;
  }
  report.punch = r.kinds.filter((k) => k === 'url').length;

  return report;
}
