import type { Page } from 'playwright';
import { humanSleep } from '../human/delays.js';
import { detectRisk } from '../human/actions.js';

/**
 * Daily check-in streak (print: Day 1 done, Day 2 highlighted).
 */
export async function runDailyCheckIn(page: Page): Promise<boolean> {
  if (await detectRisk(page)) return false;

  await page.goto('https://rewards.bing.com/', { waitUntil: 'domcontentloaded' }).catch(() => null);
  await humanSleep(1800, 0.4);

  const selectors = [
    'button:has-text("Check in")',
    'button:has-text("Check-in")',
    'button:has-text("Check-In")',
    'button:has-text("Fazer check-in")',
    'button:has-text("Registar")',
    'a:has-text("Check in")',
    '[aria-label*="Check-in" i]',
    '[aria-label*="check in" i]',
    'button:has-text("Claim")',
    'button:has-text("Resgatar")',
    // streak coin for today
    '[class*="checkin"] button',
    '[class*="check-in"] button',
    '[class*="streak"] button',
  ];

  for (const sel of selectors) {
    const loc = page.locator(sel).first();
    if (await loc.isVisible().catch(() => false)) {
      await loc.click({ delay: 60 }).catch(() => null);
      await humanSleep(2000, 0.4);
      return true;
    }
  }

  // Some UIs auto-claim on dashboard visit; treat as soft success if streak UI present
  const streak = page.locator('text=Day 1, text=Day 2, text=Check-in, text=Check-In');
  if (await streak.first().isVisible().catch(() => false)) {
    return true;
  }
  return false;
}
