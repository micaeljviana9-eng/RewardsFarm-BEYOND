import type { Page } from 'playwright';
import { humanSleep } from '../human/delays.js';
import { generateTotp } from '../auth/totp.js';

export async function goDashboard(page: Page) {
  await page.goto('https://rewards.bing.com/', { waitUntil: 'domcontentloaded' });
  await humanSleep(2000, 0.4);
}

export async function scrapePoints(page: Page): Promise<number> {
  const selectors = [
    '#balanceToolTipDiv',
    '[id*="balance"]',
    '[class*="balance"]',
    'mee-rewards-counter-animation',
    '[aria-label*="point" i]',
    '[aria-label*="ponto" i]',
  ];
  for (const sel of selectors) {
    const loc = page.locator(sel).first();
    if (await loc.count()) {
      const t = (await loc.innerText().catch(() => '')) || '';
      const m = t.replace(/\s/g, '').match(/(\d{1,3}(?:[.,]\d{3})+|\d+)/);
      if (m) {
        const n = parseInt(m[1].replace(/[.,]/g, ''), 10);
        if (n > 0) return n;
      }
    }
  }
  const text = await page.locator('body').innerText().catch(() => '');
  for (const re of [
    /(\d{1,3}(?:[.,]\d{3})+|\d+)\s*(?:pontos|points)/i,
    /(?:pontos|points)[^\d]{0,12}(\d{1,3}(?:[.,]\d{3})+|\d+)/i,
  ]) {
    const m = text.match(re);
    if (m) {
      const n = parseInt(m[1].replace(/[.,]/g, ''), 10);
      if (n > 0) return n;
    }
  }
  return 0;
}

async function fillTotpIfPresent(page: Page, totpSecret?: string): Promise<boolean> {
  if (!totpSecret) return false;
  const selectors = [
    'input[name="otc"]',
    'input[name="otp"]',
    'input[aria-label*="code" i]',
    'input[placeholder*="code" i]',
    'input[placeholder*="código" i]',
    '#idTxtBx_SAOTCC_OTC',
    'input[type="tel"]',
  ];
  for (const sel of selectors) {
    const loc = page.locator(sel).first();
    if (await loc.isVisible().catch(() => false)) {
      const code = generateTotp(totpSecret);
      await loc.fill(code);
      await humanSleep(600, 0.3);
      await page.keyboard.press('Enter');
      await humanSleep(3000, 0.4);
      console.log('[2FA] TOTP submitted');
      return true;
    }
  }
  return false;
}

export async function tryLogin(
  page: Page,
  email: string,
  password: string,
  totpSecret?: string
): Promise<boolean> {
  await goDashboard(page);

  const hasForm = await page.locator('input[type="email"], input[name="loginfmt"]').count();
  if (!hasForm) {
    const body = (await page.locator('body').innerText().catch(() => '')).toLowerCase();
    if (body.includes('reward') || body.includes('ponto') || body.includes('point')) return true;
  }

  const emailSel = 'input[type="email"], input[name="loginfmt"]';
  if (await page.locator(emailSel).count()) {
    await page.fill(emailSel, email);
    await page.keyboard.press('Enter');
    await humanSleep(2200, 0.4);

    const passSel = 'input[type="password"], input[name="passwd"]';
    if (await page.locator(passSel).count()) {
      await page.fill(passSel, password);
      await page.keyboard.press('Enter');
      await humanSleep(3500, 0.4);
    }

    // 2FA TOTP
    await fillTotpIfPresent(page, totpSecret);
    // sometimes second prompt
    await humanSleep(1500, 0.3);
    await fillTotpIfPresent(page, totpSecret);

    const stay = page.locator(
      'input[type="submit"][value*="Yes"], button:has-text("Yes"), button:has-text("Sim"), #idSIButton9'
    );
    if (await stay.count()) {
      await stay.first().click().catch(() => null);
      await humanSleep(2000, 0.4);
    }
  }

  await goDashboard(page);
  const stillForm = await page.locator('input[type="email"], input[name="loginfmt"]').count();
  if (stillForm) return false;
  const after = (await page.locator('body').innerText().catch(() => '')).toLowerCase();
  return after.includes('reward') || after.includes('ponto') || after.includes('point') || after.includes('daily');
}
