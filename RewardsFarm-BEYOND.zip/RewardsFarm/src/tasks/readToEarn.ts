import type { Page } from 'playwright';
import { humanSleep } from '../human/delays.js';
import { dwell, detectRisk, humanClick } from '../human/actions.js';

/**
 * Read to Earn — print shows 0/30.
 * Strategy: open Rewards/Bing feed articles, dwell, next article loop.
 * (Full 30 often needs Bing app / mobile API token; browser gets partial–full depending on market.)
 */
export async function runReadToEarn(page: Page, maxArticles = 10): Promise<number> {
  let done = 0;
  if (await detectRisk(page)) return -1;

  // Entry points
  const entries = [
    'a:has-text("Ler para ganhar")',
    'a:has-text("Read to earn")',
    'a:has-text("Read to Earn")',
    '[aria-label*="Read to earn" i]',
    '[aria-label*="Ler para ganhar" i]',
    'a[href*="read"]',
  ];

  let opened = false;
  for (const sel of entries) {
    const loc = page.locator(sel).first();
    if (await loc.isVisible().catch(() => false)) {
      await loc.click({ delay: 60 }).catch(() => null);
      opened = true;
      await humanSleep(2000, 0.4);
      break;
    }
  }

  if (!opened) {
    // Try MSN / Bing news as read proxy
    await page.goto('https://www.bing.com/news', { waitUntil: 'domcontentloaded' }).catch(() => null);
    await humanSleep(2000, 0.4);
  }

  for (let i = 0; i < maxArticles; i++) {
    if (await detectRisk(page)) return done;

    // Click an article card
    const article = page.locator(
      'a[href*="/news/"], a[href*="msn.com"], article a, .news-card a, [class*="news"] a, [data-tag*="news"] a'
    ).nth(i % 8);
    if (await article.isVisible().catch(() => false)) {
      await article.click({ delay: 50 }).catch(() => null);
      await humanSleep(2000, 0.4);
      await dwell(page, 5000);
      done++;
      // back
      await page.goBack().catch(() => null);
      await humanSleep(1200, 0.4);
    } else {
      await dwell(page, 4000);
      done++;
    }
  }

  return done;
}
