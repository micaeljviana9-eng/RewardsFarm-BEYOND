import type { Page } from 'playwright';
import { humanType, humanClick, dwell, detectRisk, humanScroll } from '../human/actions.js';
import { humanSleep } from '../human/delays.js';
import { aggressionProfile } from '../util/config.js';
import type { Aggression } from '../util/types.js';

const FALLBACK_QUERIES = [
  'como aprender python do zero', 'cotação dólar agora', 'previsão tempo são paulo',
  'notícias tecnologia ia', 'melhores fones 2026', 'receita bolo de cenoura',
  'vagas home office', 'como investir tesouro direto', 'iphone preço brasil',
  'treino academia iniciantes', 'melhores séries 2026', 'como usar chatgpt',
  'energia solar residencial', 'dicas produtividade', 'praias nordeste',
  'segurança digital dicas', 'carros elétricos 2026', 'fotografia com celular',
  'plantas apartamento', 'windows 11 dicas', 'receita pão de queijo',
  'futebol resultados hoje', 'melhores notebooks estudo', 'como fazer pix',
];

function pickQueries(n: number): string[] {
  const pool = [...FALLBACK_QUERIES];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const out: string[] = [];
  while (out.length < n) {
    const base = pool[out.length % pool.length];
    const q = Math.random() < 0.15 ? `${base} ${2025 + Math.floor(Math.random() * 2)}` : base;
    out.push(q);
  }
  return out;
}

export async function runSearches(
  page: Page,
  count: number,
  aggression: Aggression,
  baseGap: number,
  burstEvery: number,
  burstCooldown: number
): Promise<{ done: number; risk: boolean }> {
  const prof = aggressionProfile(aggression);
  const n = Math.min(count, prof.desktopMax);
  const queries = pickQueries(n);
  let done = 0;

  await page.goto('https://www.bing.com/', { waitUntil: 'domcontentloaded' });
  await humanSleep(1500, 0.4, prof.delayMult);

  for (let i = 0; i < queries.length; i++) {
    if (await detectRisk(page)) return { done, risk: true };

    const q = queries[i];
    // Prefer typing into search box
    const box = page.locator('input[name="q"], #sb_form_q, textarea[name="q"]').first();
    const visible = await box.isVisible().catch(() => false);
    if (visible) {
      await humanType(page, 'input[name="q"], #sb_form_q, textarea[name="q"]', q, prof.delayMult);
      await page.keyboard.press('Enter');
    } else {
      await page.goto(`https://www.bing.com/search?q=${encodeURIComponent(q)}`, {
        waitUntil: 'domcontentloaded',
      });
    }

    await page.waitForLoadState('domcontentloaded').catch(() => null);
    await dwell(page, 4000, prof.delayMult);

    if (Math.random() < 0.2) {
      const link = page.locator('#b_results h2 a, .b_algo h2 a').first();
      if (await link.isVisible().catch(() => false)) {
        await humanClick(page, '#b_results h2 a, .b_algo h2 a', prof.delayMult);
        await humanSleep(2500, 0.5, prof.delayMult);
        await page.goBack().catch(() => null);
        await humanSleep(1200, 0.4, prof.delayMult);
      }
    }

    done++;
    const every = burstEvery || prof.antiBurstEvery;
    if (done % every === 0 && done < queries.length) {
      await humanSleep(burstCooldown, 0.35, prof.delayMult);
    } else {
      await humanSleep(baseGap, 0.5, prof.delayMult);
    }
  }

  return { done, risk: false };
}
