import type { Page } from 'playwright';
import { humanType, humanClick, dwell, detectRisk } from '../human/actions.js';
import { humanSleep } from '../human/delays.js';
import type { Aggression } from '../util/types.js';
import { aggressionProfile } from '../util/config.js';

/**
 * Search chains > independent random queries.
 * Real humans refine: query → related → back → new topic.
 * Most weak farms only fire isolated URLs.
 */
const TOPICS = [
  ['inteligencia artificial noticias', 'como funciona chatgpt', 'melhores cursos de ia'],
  ['cotação dólar', 'investimentos renda fixa', 'tesouro direto 2026'],
  ['receita bolo de cenoura', 'como fazer cobertura de chocolate', 'forno e temperatura bolo'],
  ['futebol resultados', 'tabela brasileirão', 'próximos jogos'],
  ['iphone preço brasil', 'comparar galaxy s24', 'melhor celular custo benefício'],
  ['previsão tempo', 'chuva esta semana', 'clima fim de semana'],
  ['vagas home office', 'como fazer currículo', 'entrevista de emprego dicas'],
  ['treino academia', 'dieta high protein', 'suplementos whey'],
];

function pickChains(n: number): string[] {
  const queries: string[] = [];
  const shuffled = [...TOPICS].sort(() => Math.random() - 0.5);
  for (const chain of shuffled) {
    for (const q of chain) {
      queries.push(q);
      if (queries.length >= n) return queries;
    }
    // sometimes break chain early (human distraction)
    if (Math.random() < 0.25) continue;
  }
  while (queries.length < n) {
    queries.push(shuffled[0][Math.floor(Math.random() * shuffled[0].length)]);
  }
  return queries;
}

export async function runSearchChains(
  page: Page,
  count: number,
  aggression: Aggression,
  baseGap: number,
  burstEvery: number,
  burstCooldown: number
): Promise<{ done: number; risk: boolean; noCreditStreak: number }> {
  const prof = aggressionProfile(aggression);
  const n = Math.min(count, prof.desktopMax);
  const queries = pickChains(n);
  let done = 0;
  let noCreditStreak = 0;

  await page.goto('https://www.bing.com/', { waitUntil: 'domcontentloaded' });
  await humanSleep(1600, 0.4, prof.delayMult);

  for (let i = 0; i < queries.length; i++) {
    if (await detectRisk(page)) return { done, risk: true, noCreditStreak };

    const q = queries[i];
    const box = page.locator('input[name="q"], #sb_form_q, textarea[name="q"]').first();
    if (await box.isVisible().catch(() => false)) {
      await box.click({ clickCount: 3 }).catch(() => null);
      await humanType(page, 'input[name="q"], #sb_form_q, textarea[name="q"]', q, prof.delayMult);
      await page.keyboard.press('Enter');
    } else {
      await page.goto(`https://www.bing.com/search?q=${encodeURIComponent(q)}`, { waitUntil: 'domcontentloaded' });
    }

    await page.waitForLoadState('domcontentloaded').catch(() => null);
    await dwell(page, 4500 + Math.floor(Math.random() * 3000), prof.delayMult);

    // Related search click (chain behavior)
    if (Math.random() < 0.35) {
      const related = page.locator('.b_rs a, #brsv3 a, .b_attribution + a').first();
      if (await related.isVisible().catch(() => false)) {
        await humanClick(page, '.b_rs a, #brsv3 a', prof.delayMult);
        await humanSleep(2800, 0.5, prof.delayMult);
      }
    } else if (Math.random() < 0.2) {
      const result = page.locator('#b_results h2 a, .b_algo h2 a').first();
      if (await result.isVisible().catch(() => false)) {
        await humanClick(page, '#b_results h2 a, .b_algo h2 a', prof.delayMult);
        await humanSleep(3000, 0.5, prof.delayMult);
        await page.goBack().catch(() => null);
        await humanSleep(1200, 0.4, prof.delayMult);
      }
    }

    done++;
    const every = burstEvery || prof.antiBurstEvery;
    if (done % every === 0 && done < queries.length) {
      await humanSleep(burstCooldown, 0.35, prof.delayMult);
    } else {
      await humanSleep(baseGap, 0.5, prof.delayMult);
    }
  }

  return { done, risk: false, noCreditStreak };
}
