import crypto from 'crypto';

/**
 * Per-account preferred run window — not everyone at 08:00.
 * Deterministic from email so the same account keeps a stable "habit".
 */
export function preferredHour(email: string, startHour = 8, endHour = 22): number {
  const h = crypto.createHash('sha256').update(email + 'hour').digest();
  const span = Math.max(1, endHour - startHour);
  return startHour + (h[0] % span);
}

export function preferredMinute(email: string): number {
  const h = crypto.createHash('sha256').update(email + 'minute').digest();
  return h[0] % 60;
}

/** Extra jitter seconds unique per account per day */
export function dailyJitterSec(email: string, maxSec = 2400): number {
  const day = new Date().toISOString().slice(0, 10);
  const h = crypto.createHash('sha256').update(email + day + 'jitter').digest();
  const v = h[0] + h[1] * 256;
  return v % maxSec;
}

export function shouldRunNow(email: string, startHour = 8, endHour = 22, windowHours = 2): boolean {
  const now = new Date();
  const hour = now.getHours();
  if (hour < startHour || hour >= endHour) return false;
  const pref = preferredHour(email, startHour, endHour);
  // allow window around preferred hour
  const dist = Math.min(Math.abs(hour - pref), 24 - Math.abs(hour - pref));
  return dist <= windowHours;
}
