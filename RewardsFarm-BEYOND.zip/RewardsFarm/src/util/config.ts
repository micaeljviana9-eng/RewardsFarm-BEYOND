import fs from 'fs';
import path from 'path';
import type { Account, FarmConfig, Aggression } from './types.js';

export function loadConfig(file = process.env.CONFIG_FILE || './config/default.json'): FarmConfig {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  return raw as FarmConfig;
}

export function loadAccounts(file = process.env.ACCOUNTS_FILE || './data/accounts.json'): Account[] {
  if (!fs.existsSync(file)) {
    throw new Error(`Accounts file missing: ${file} — copy data/accounts.example.json`);
  }
  const list = JSON.parse(fs.readFileSync(file, 'utf8')) as Account[];
  return list.filter(a => a.enabled !== false);
}

export function aggressionProfile(a: Aggression) {
  switch (a) {
    case 'SAFE':
      return { delayMult: 1.7, desktopMax: 18, mobileMax: 12, antiBurstEvery: 2, votes: 5 };
    case 'AGGRESSIVE':
      return { delayMult: 0.7, desktopMax: 30, mobileMax: 20, antiBurstEvery: 5, votes: 10 };
    default:
      return { delayMult: 1.0, desktopMax: 26, mobileMax: 18, antiBurstEvery: 3, votes: 8 };
  }
}

export function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

export function sessionDir(base: string, email: string) {
  const safe = email.replace(/[^a-zA-Z0-9._-]/g, '_');
  const dir = path.join(base, safe);
  ensureDir(dir);
  return dir;
}
