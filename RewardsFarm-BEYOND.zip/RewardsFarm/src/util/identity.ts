import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

/**
 * Sticky per-account identity: viewport, locale, timezone, UA family, geo hint.
 * Farms that randomize fingerprint every run lose; we bind once and keep.
 */
export interface Identity {
  email: string;
  viewport: { width: number; height: number };
  deviceScaleFactor: number;
  locale: string;
  timezoneId: string;
  userAgentDesktop: string;
  userAgentMobile: string;
  hwConcurrency: number;
  deviceMemory: number;
  seed: string;
}

const DESKTOP_UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
];

const MOBILE_UAS = [
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36',
];

function pick<T>(arr: T[], seed: string, salt: string): T {
  const h = crypto.createHash('sha256').update(seed + salt).digest();
  return arr[h[0] % arr.length];
}

function num(seed: string, salt: string, min: number, max: number) {
  const h = crypto.createHash('sha256').update(seed + salt).digest();
  const v = h[0] + h[1] * 256;
  return min + (v % (max - min + 1));
}

export function loadOrCreateIdentity(sessionRoot: string, email: string, locale: string, timezoneId: string): Identity {
  const dir = path.join(sessionRoot, email.replace(/[^a-zA-Z0-9._-]/g, '_'));
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'identity.json');
  if (fs.existsSync(file)) {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  }
  const seed = crypto.createHash('sha256').update(email + Date.now()).digest('hex').slice(0, 16);
  const id: Identity = {
    email,
    viewport: {
      width: num(seed, 'vw', 1280, 1440),
      height: num(seed, 'vh', 800, 960),
    },
    deviceScaleFactor: 1,
    locale,
    timezoneId,
    userAgentDesktop: pick(DESKTOP_UAS, seed, 'ua-d'),
    userAgentMobile: pick(MOBILE_UAS, seed, 'ua-m'),
    hwConcurrency: pick([4, 8, 12, 16], seed, 'hw'),
    deviceMemory: pick([4, 8, 8, 16], seed, 'mem'),
    seed,
  };
  fs.writeFileSync(file, JSON.stringify(id, null, 2));
  return id;
}
