import fs from 'fs';
import path from 'path';

/** Per-account daily progress — avoid always maxing the same shape */
export interface DayProgress {
  date: string; // YYYY-MM-DD
  desktopSearches: number;
  mobileSearches: number;
  cardsDone: number;
  lastEarned: number;
  softThrottleHits: number;
  completed: boolean;
}

const root = path.join(process.cwd(), 'data', 'progress');

function today() {
  return new Date().toISOString().slice(0, 10);
}

function file(email: string) {
  fs.mkdirSync(root, { recursive: true });
  return path.join(root, email.replace(/[^a-zA-Z0-9._-]/g, '_') + '.json');
}

export function loadProgress(email: string): DayProgress {
  const f = file(email);
  const d = today();
  try {
    const p = JSON.parse(fs.readFileSync(f, 'utf8')) as DayProgress;
    if (p.date === d) return p;
  } catch { /* new day */ }
  return {
    date: d,
    desktopSearches: 0,
    mobileSearches: 0,
    cardsDone: 0,
    lastEarned: 0,
    softThrottleHits: 0,
    completed: false,
  };
}

export function saveProgress(email: string, p: DayProgress) {
  fs.writeFileSync(file(email), JSON.stringify(p, null, 2));
}
