/**
 * Proxy-per-account is mandatory for multi-account survival.
 * Format: http://user:pass@host:port | socks5://user:pass@host:port
 */

export interface ParsedProxy {
  server: string;
  username?: string;
  password?: string;
  protocol: string;
  host: string;
  port: string;
  raw: string;
}

export function parseProxyUrl(proxyUrl: string): ParsedProxy | null {
  if (!proxyUrl || !proxyUrl.trim()) return null;
  const raw = proxyUrl.trim();
  try {
    // allow host:port:user:pass (common residential format)
    if (!raw.includes('://') && raw.split(':').length === 4) {
      const [host, port, user, pass] = raw.split(':');
      return {
        server: `http://${host}:${port}`,
        username: user,
        password: pass,
        protocol: 'http',
        host,
        port,
        raw: `http://${user}:${pass}@${host}:${port}`,
      };
    }
    const withProto = raw.includes('://') ? raw : `http://${raw}`;
    const u = new URL(withProto);
    if (!u.hostname || !u.port) return null;
    return {
      server: `${u.protocol}//${u.hostname}:${u.port}`,
      username: u.username ? decodeURIComponent(u.username) : undefined,
      password: u.password ? decodeURIComponent(u.password) : undefined,
      protocol: u.protocol.replace(':', ''),
      host: u.hostname,
      port: u.port,
      raw: withProto,
    };
  } catch {
    return null;
  }
}

export function assertAccountProxies(
  accounts: { email: string; proxy?: string }[],
  opts: { requireAll: boolean }
): { ok: true } | { ok: false; errors: string[] } {
  const errors: string[] = [];
  if (accounts.length >= 2 || opts.requireAll) {
    for (const a of accounts) {
      if (!a.proxy?.trim()) {
        errors.push(`${a.email}: proxy ausente (obrigatório com 2+ contas)`);
        continue;
      }
      const p = parseProxyUrl(a.proxy);
      if (!p) errors.push(`${a.email}: proxy inválido → ${a.proxy}`);
    }
  } else if (accounts.length === 1 && accounts[0].proxy) {
    const p = parseProxyUrl(accounts[0].proxy!);
    if (!p) errors.push(`${accounts[0].email}: proxy inválido`);
  }
  return errors.length ? { ok: false, errors } : { ok: true };
}

/** Playwright proxy option */
export function toPlaywrightProxy(proxyUrl?: string) {
  const p = proxyUrl ? parseProxyUrl(proxyUrl) : null;
  if (!p) return undefined;
  return {
    server: p.server,
    username: p.username,
    password: p.password,
  };
}
