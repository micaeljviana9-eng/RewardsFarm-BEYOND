import fs from 'fs';
import path from 'path';

const STORE = path.join(process.cwd(), 'data', 'risk-state.json');

type State = Record<string, { until: number; reason: string }>;

function read(): State {
  try {
    return JSON.parse(fs.readFileSync(STORE, 'utf8'));
  } catch {
    return {};
  }
}

function write(s: State) {
  fs.mkdirSync(path.dirname(STORE), { recursive: true });
  fs.writeFileSync(STORE, JSON.stringify(s, null, 2));
}

export function isCoolingDown(email: string): boolean {
  const s = read();
  const e = s[email];
  return !!(e && Date.now() < e.until);
}

export function hoursLeft(email: string): number {
  const s = read();
  const e = s[email];
  if (!e) return 0;
  return Math.max(0, Math.ceil((e.until - Date.now()) / 3600000));
}

export function markRisk(email: string, reason: string, hours = 6) {
  const s = read();
  s[email] = { until: Date.now() + hours * 3600000, reason };
  write(s);
  console.warn(`[Risk] ${email} cooldown ${hours}h — ${reason}`);
}
