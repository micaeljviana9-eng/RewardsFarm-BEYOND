export type Aggression = 'SAFE' | 'NORMAL' | 'AGGRESSIVE';

export interface Account {
  email: string;
  password: string;
  proxy?: string;
  locale?: string;
  /** Base32 TOTP secret (Microsoft authenticator) */
  totpSecret?: string;
  enabled?: boolean;
}

export interface FarmConfig {
  headless: boolean;
  aggression: Aggression;
  clusters: number;
  sessionPath: string;
  globalTimeoutMs: number;
  desktopSearches: number;
  mobileSearches: number;
  doDailySet: boolean;
  doPromotions: boolean;
  doPunchCards: boolean;
  doDesktopSearch: boolean;
  doMobileSearch: boolean;
  searchAntiBurstEvery: number;
  searchBaseGapMs: number;
  searchBurstCooldownMs: number;
  riskCooldownHours: number;
  jitterStartMinutes: number;
  locale: string;
  timezoneId: string;
  softThrottleAbortAfter?: number;
  varyDayShape?: boolean;
}

export interface RunResult {
  email: string;
  success: boolean;
  pointsBefore: number;
  pointsAfter: number;
  earned: number;
  risk: boolean;
  notes: string[];
  error?: string;
}
